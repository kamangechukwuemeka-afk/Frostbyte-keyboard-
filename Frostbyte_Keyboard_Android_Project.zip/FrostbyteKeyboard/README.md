# Frostbyte Keyboard

Native Android keyboard starter project for Android 6.0+.

## Included
- Android keyboard (IME) with compact dark-and-blue design.
- App launcher screen with shortcuts to enable and select the keyboard.
- A classic blue circular verification-tick action.
- Attempts rich PNG insertion on Android 7.1+ in apps that accept image content via `InputConnection.commitContent`.
- Falls back to `🔵✓` text when rich content is rejected.
- No network permission; this starter does not send typed text to a server.

## Important compatibility note
A keyboard cannot force every app to accept inline images. Each receiving app decides whether it accepts rich-content input. The text fallback is broadly supported but is not a single custom Unicode emoji. Test in each target app.

## Build APK with Android Studio
1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 if prompted.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install `app/build/outputs/apk/debug/app-debug.apk`.
6. Open Frostbyte Keyboard, tap **Enable Frostbyte Keyboard**, enable it in system settings, return, then tap **Choose Frostbyte Keyboard**.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Run **Build Frostbyte Keyboard APK** (or push to `main`).
4. Download the `Frostbyte-Keyboard-debug-apk` artifact from the completed workflow.

## Project status
This is source code plus an automated build workflow, not a precompiled APK. A local Android SDK/Gradle build environment is required to produce the APK.
