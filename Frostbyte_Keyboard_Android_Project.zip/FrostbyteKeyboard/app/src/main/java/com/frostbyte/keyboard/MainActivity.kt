package com.frostbyte.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val blue = Color.rgb(30, 115, 235)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(18, 22, 30))
        }
        val title = TextView(this).apply {
            text = "FROSTBYTE KEYBOARD"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val tick = TextView(this).apply {
            text = "🔵✓"
            textSize = 54f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val info = TextView(this).apply {
            text = "Your compact blue-tick keyboard is ready to set up. Enable it in Android settings, then choose it as your current keyboard."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        val settings = Button(this).apply {
            text = "1. Enable Frostbyte Keyboard"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. Choose Frostbyte Keyboard"
            isAllCaps = false
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        }
        val note = TextView(this).apply {
            text = "Privacy: this starter keyboard has no network permission and does not send typed text anywhere. Rich tick insertion depends on whether the app you're typing in accepts image input."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 26, 0, 0)
        }
        root.addView(title)
        root.addView(tick)
        root.addView(info)
        root.addView(settings, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        root.addView(choose, LinearLayout.LayoutParams(-1, -2))
        root.addView(note)
        setContentView(root)
    }
}
