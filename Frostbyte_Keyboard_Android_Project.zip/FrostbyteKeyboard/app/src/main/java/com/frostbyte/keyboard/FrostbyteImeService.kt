package com.frostbyte.keyboard

import android.inputmethodservice.InputMethodService
import android.content.ClipDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputContentInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FrostbyteImeService : InputMethodService() {
    private val blue = Color.rgb(30, 115, 235)

    override fun onCreateInputView(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 8, 5, 8)
            setBackgroundColor(Color.rgb(22, 25, 32))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "FROSTBYTE"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(8, 8, 8, 8)
        }
        val tick = Button(this).apply {
            text = "🔵✓  Insert tick"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue))
            setOnClickListener { insertTick() }
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(tick)
        outer.addView(top)

        val rows = listOf("qwertyuiop", "asdfghjkl", "⇧zxcvbnm⌫")
        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { ch ->
                val label = ch.toString()
                val key = Button(this).apply {
                    text = label
                    isAllCaps = false
                    textSize = 18f
                    setTextColor(Color.WHITE)
                    setPadding(0, 0, 0, 0)
                    setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65, 70, 82)))
                    setOnClickListener {
                        when (ch) {
                            '⌫' -> currentInputConnection?.deleteSurroundingText(1, 0)
                            '⇧' -> { /* Shift is visual only in this starter build. */ }
                            else -> currentInputConnection?.commitText(label, 1)
                        }
                    }
                }
                line.addView(key, LinearLayout.LayoutParams(0, 48, 1f).apply {
                    setMargins(2, 2, 2, 2)
                })
            }
            outer.addView(line)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun special(text: String, weight: Float, action: () -> Unit) {
            val b = Button(this).apply {
                this.text = text
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65, 70, 82)))
                setOnClickListener { action() }
            }
            bottom.addView(b, LinearLayout.LayoutParams(0, 48, weight).apply { setMargins(2, 2, 2, 2) })
        }
        special("?123", 1f) { currentInputConnection?.commitText("123", 1) }
        special(",", .7f) { currentInputConnection?.commitText(",", 1) }
        special("English", 1.4f) { currentInputConnection?.commitText(" ", 1) }
        special(".", .7f) { currentInputConnection?.commitText(".", 1) }
        special("↵", 1f) { currentInputConnection?.performEditorAction(currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE) }
        outer.addView(bottom)
        return outer
    }

    private fun insertTick() {
        val ic = currentInputConnection ?: return
        if (Build.VERSION.SDK_INT >= 25) {
            try {
                val uri = Uri.parse("content://com.frostbyte.keyboard.content/tick.png")
                val description = ClipDescription("Frostbyte blue verification tick", arrayOf("image/png"))
                val content = InputContentInfo(uri, description, null)
                val opts = Bundle()
                val accepted = ic.commitContent(content, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, opts)
                if (accepted) return
            } catch (_: Exception) { }
        }
        // Universal text fallback; appearance depends on the receiving app's emoji font.
        ic.commitText("🔵✓", 1)
    }
}
